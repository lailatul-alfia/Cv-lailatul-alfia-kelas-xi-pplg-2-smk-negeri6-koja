<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
$database= mysqli_connect('localhost','root','','Cv_alfia');//menampilkan Nama database
$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT*FROM cv_alfia WHERE no=$hapus");

if(isset ($_POST["tombol"])){
    $no = $_POST ["no"];
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $hobi = $_POST ["hobi"];
    $alamat = $_POST ["alamat"];
    $skill = $_POST ["skill"];
    $nomor_telepon = $_POST ["nomor_telepon"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $sifat_saya = $_POST ["sifat_saya"];
   
   
    $edit = "UPDATE cv_alfia SET
    nama = '$nama',
     jenis_kelamin = '$jenis_kelamin',
    hobi = '$hobi',
    alamat = '$alamat',
    skill = '$skill',
    nomor_telepon= '$nomor_telepon',
    pendidikan = '$pendidikan',
    pekerjaan = '$pekerjaan',
    sifat_saya = '$sifat_saya'
    WHERE no=$hapus";

    mysqli_query($database,$edit);
    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Edit Data</title>
</head>
<body>

<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Data</h2>
    <form method="POST">
    <input type="hidden" name="no" value="<?= $cari ['no'];?>">
<ul>
<li><label >Nama</label></li>
<li><input type="text" name="nama" value="<?= $cari ['nama'];?>"></li>
<li><label >jenis_kelamin</label></li>
<li><input type="text" name="jenis_kelamin" value="<?= $cari ['jenis_kelamin'];?>"></li>
<li><label >hobi</label></li>
    <li><input type="text" name="hobi" value="<?= $cari ['hobi'];?>"></li>
    <li><label >alamat</label></li>
    <li><input type="text" name="alamat" value="<?= $cari ['alamat'];?>"></li>
    <li><label >skill</label></li>
    <li><input type="text" name="skill" value="<?= $cari ["skill"];?>"></li>
    <li><label >No HP</label></li>
    <li><input type="text" name="nomor_telepon" value="<?php echo $cari ['nomor_telepon'];?>"></li>
    <li><label >pendidikan</label></li>
    <li><textarea name="pendidikan" id=""><?php echo $cari ['pendidikan'];?>"</textarea></li>
    <li><label >pekerjaan</label></li>
    <li><textarea name="pekerjaan" id=""><?= $cari ["pekerjaan"];?></textarea></li>
    <li><label >sifat_saya</label></li>
    <li><textarea name="sifat_saya" id=""><?= $cari ["sifat_saya"];?></textarea></li>
    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>