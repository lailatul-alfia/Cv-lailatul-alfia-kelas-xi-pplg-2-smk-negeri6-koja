<?php
$database= mysqli_connect('localhost','root','','Cv_alfia');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $jenis_kelamin = $_POST ["jenis_kelamin"];
    $hobi = $_POST ["hobi"];
    $alamat = $_POST ["alamat"];
    $skill = $_POST ["skill"];
    $nomor_telepon = $_POST ["nomor_telepon"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $sifat_saya = $_POST ["sifat_saya"];
    $tambah = "INSERT INTO cv_alfia VALUE
    ('','$nama','$jenis_kelamin','$hobi','$alamat','$skill','$nomor_telepon','$pendidikan','$pekerjaan','$sifat_saya')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM cv_alfia where no=$hapus");
    return mysqli_affected_rows($database);
}


?>