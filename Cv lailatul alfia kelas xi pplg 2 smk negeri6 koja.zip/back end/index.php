<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}

require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM cv_alfia");
if (isset ($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
    $datayangdicari= "SELECT *FROM cv_alfia WHERE
    nama like '%$Pencarian%' or
    jenis_kelamin like '%$Pencarian%' or
    hobi like '%$Pencarian%' or
    alamat like '%$Pencarian%' or
    skill like '%$Pencarian%' or
    nomor_telepon like '%$Pencarian%' or
    pendidikan like '%$Pencarian%' or
    pekerjaan like '%$Pencarian%' or
   sifat_saya like '%$Pencarian%'";
    $cari= mysqli_query ($database,$datayangdicari);
} else {
    $cari= mysqli_query ($database,'SELECT*FROM cv_alfia');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
    <div id="logo-atas">
<img src="logo.png" alt="Logo Sekolah">
    </div>
    <div id="header-title">
<a href="index.php">CURRICULUM VITAE</a>
    </div>
    </div>
    <div class="menu">
        <ul class="menu-item">
        <li class="menu-item"><a href="data.php">Beranda</a></li>
        <li class="menu-item"><a href="index.php">Data</a></li>
        <li class="menu-item"><a href="tambah.php">Tambah Data</a></li>
        <li class="menu-item"><a href="tentang.php">Tentang Kami</a></li>
        <li class="menu-item"><a href="login.php">Keluar</a></li>
        </ul>
    </div>
    <div class="konten">
<h1>CURRICULUM VITAE</h1> 
 
<a href="tambah.php">Tambah</a>
<form action="" method="post">
    <input type="text" name="pencarian">
    <button type="submit" name="tombol">Cari</button>
</form>
<div class="tabel">
<table border="1" cellspadding="20" callspacing= "10">
    <tr class="tabel-header">
        <th>No</th>
        <th>Nama</th>
        <th>jenis_kelamin</th>
        <th>hobi</th>
        <th>alamat</th>
        <th>skill</th>
        <th>nomor_telepon</th>
        <th>Pendidikan</th>
        <th>pekerjaan</th>
        <th>sifat_saya</th>
    </tr>
    <?php
    $nomor= 1; 
    ?>
    <?php
    foreach ($cari as $cari2):
    ?>
     <tr>
        <td class="tabel-header1"><?= $nomor;?></td>
        <td class="tabel-header2"><?= $cari2 ['nama'];?></td>
        <td class="tabel-header3"><?= $cari2 ['jenis_kelamin'];?></td>
        <td class="tabel-header4"><?= $cari2 ['hobi'];?></td>
        <td class="tabel-header5"><?= $cari2 ['alamat'];?></td>
        <td class="tabel-header6"><?php echo $cari2 ['skill'];?></td>
        <td class="tabel-header7"><?php echo $cari2 ['nomor_telepon'];?></td>
        <td class="tabel-header8"><?= $cari2 ['pendidikan'];?></td>
        <td class="tabel-header9"><?= $cari2 ['pekerjaan'];?></td>
        <td class="tabel-header10"><?= $cari2 ['sifat_saya'];?></td>
        </select></td>
        <td><a href="edit.php?no=<?= $cari2 ["no"]?>">Edit</a> |
            <a href="hapus.php?no=<?= $cari2 ["no"]?>">Hapus</a>
            <a href="keluar.php?no=<?= $cari2 ["no"]?>">Keluar</a>
        </td>
    </tr>
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
  </table>
    <?php
    $nomor= 1; 
    ?>
    <?php
    foreach ($cari as $cari2):
    ?>
     
    <?php
    $nomor++;
    ?>
    <?php
    endforeach;
    ?>
  </table>


  </div>
  </div>
</body>
</html>