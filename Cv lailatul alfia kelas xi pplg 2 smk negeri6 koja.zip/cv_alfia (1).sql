-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2025 at 09:57 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv_alfia`
--

-- --------------------------------------------------------

--
-- Table structure for table `cv_alfia`
--

CREATE TABLE `cv_alfia` (
  `no` int(11) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `jenis_kelamin` varchar(10000) NOT NULL,
  `hobi` varchar(20) NOT NULL,
  `alamat` varchar(1000) NOT NULL,
  `skill` varchar(1000) NOT NULL,
  `nomor_telepon` varchar(1000) NOT NULL,
  `pendidikan` text NOT NULL,
  `pekerjaan` text NOT NULL,
  `sifat_saya` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cv_alfia`
--

INSERT INTO `cv_alfia` (`no`, `nama`, `jenis_kelamin`, `hobi`, `alamat`, `skill`, `nomor_telepon`, `pendidikan`, `pekerjaan`, `sifat_saya`) VALUES
(3, 'laIlatul alfia', 'p', 'galau', ' Jalan kerajaan Melayu Rt 09', 'menciptakan ide mindblowing', '083173604999', '-Sekolah Dasar:SDN 1 Belitang Madang Raya\r\n\r\n-Sekolah Menengah Pertama:SMP N 1 Belitang Madang Raya\r\n\r\n-Sekolah Menengah Awal:SMK N 6 Kota Jambi\"\"\"\"\"\"', 'Dirumah:beres-beres rumah\r\n\r\nSekolah:Belajar dan mencari pengalaman', 'introvert\r\nambisi\r\n\r\npeka\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`no`, `username`, `password`) VALUES
(1, 'park hyung sik', 'burried heart');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cv_alfia`
--
ALTER TABLE `cv_alfia`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cv_alfia`
--
ALTER TABLE `cv_alfia`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
