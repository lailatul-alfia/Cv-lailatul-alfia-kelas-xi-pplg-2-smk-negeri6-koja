<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM cv_alfia");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> CV LAELATUL ALFIAH</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="screenshot .jpg" alt="ini screensho anak ph">
    </div>

    <?php
    foreach ($cari as $cari2):
    ?>
    <h1><?= $cari2 ['nama'];?></h1>
    <h3><?= $cari2 ['hobi'];?></h3>
    <?php
    endforeach;
    ?>
    </div>
    <div class="main">
    <div class="left">
     <h2>informasi identitas</h2>
     <p><strong>Nama</strong> <?= $cari2 ['nama'];?></p>
     <p><strong>jenis_kelamin</strong> <?= $cari2 ['jenis_kelamin'];?></p>
     <p><strong>Alamat</strong><?= $cari2 ['alamat'];?></p>
     <p><strong>No Telepon</strong> <?php echo $cari2 ['nomor_telepon'];?></p>
     <p><strong>Skill</strong> <?php echo $cari2 ['skill'];?>6</p>
     <h2>Pendidikan</h2>
    <p><strong><?= $cari2 ['pendidikan'];?></strong></p>
    </div>
    <div class="right">
        <h2>Perkerjaan</h2>
       <p><strong><?= $cari2 ['pekerjaan'];?></strong></p>
        <h2>Kepribadian</h2>
        <p><strong>sifat saya</strong></p>
        <li> <?= $cari2 ['sifat_saya'];?></li>
       
    </div>
    </div>
    </div>
</body>
</html>